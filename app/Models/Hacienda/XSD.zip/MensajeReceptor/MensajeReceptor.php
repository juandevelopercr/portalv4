<?php

namespace App\XSDClasses\MensajeReceptor;

use App\XSDClasses\MensajeReceptor\MensajeReceptor\MensajeReceptorAType;

/**
 * Class representing MensajeReceptor
 *
 * Mensaje de aceptacion o rechazo de los documentos electronicos por parte del obligado tributario
 */
class MensajeReceptor extends MensajeReceptorAType
{
}

