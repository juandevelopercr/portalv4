<?php

namespace App\XSDClasses\MensajeReceptor\MensajeReceptor;

/**
 * Class representing MensajeReceptorAType
 */
class MensajeReceptorAType
{
    /**
     * Clave numérica del comprobante
     *
     * @var string $clave
     */
    private $clave = null;

    /**
     * Número de cédula fisica/jurídica/NITE/DIMEX/Extranjero No Domiciliado/No Contribuyente del vendedor
     *
     * @var string $numeroCedulaEmisor
     */
    private $numeroCedulaEmisor = null;

    /**
     * Fecha de emision de la confirmación
     *
     * @var \DateTime $fechaEmisionDoc
     */
    private $fechaEmisionDoc = null;

    /**
     * Codigo del mensaje de respuesta. 1 aceptado, 2 aceptado parcialmente, 3 rechazado
     *
     * @var int $mensaje
     */
    private $mensaje = null;

    /**
     * Detalle del mensaje
     *
     * @var string $detalleMensaje
     */
    private $detalleMensaje = null;

    /**
     * Monto total del impuesto, que es obligatorio si el comprobante tenga impuesto.
     *
     * @var float $montoTotalImpuesto
     */
    private $montoTotalImpuesto = null;

    /**
     * Código Actividad Económica
     *
     * @var string $codigoActividad
     */
    private $codigoActividad = null;

    /**
     * Condición del IVA. 01 General Credito IVA, 02 General Crédito parcial del IVA, 03 Bienes de Capital, 04 Gasto corriente no genera crédito, 05 Proporcionalidad
     *
     * @var string $condicionImpuesto
     */
    private $condicionImpuesto = null;

    /**
     * Monto del Impuesto acreditar
     *
     * @var float $montoTotalImpuestoAcreditar
     */
    private $montoTotalImpuestoAcreditar = null;

    /**
     * Monto total del gasto a aplicar
     *
     * @var float $montoTotalDeGastoAplicable
     */
    private $montoTotalDeGastoAplicable = null;

    /**
     * Monto total de la factura
     *
     * @var float $totalFactura
     */
    private $totalFactura = null;

    /**
     * Número de cédula fisica/jurídica/NITE/DIMEX/Extranjero No Domiciliado/No Contribuyente del comprador
     *
     * @var string $numeroCedulaReceptor
     */
    private $numeroCedulaReceptor = null;

    /**
     * Numeración consecutiva de los mensajes de confirmación
     *
     * @var string $numeroConsecutivoReceptor
     */
    private $numeroConsecutivoReceptor = null;

    /**
     * @var \App\XSDClasses\XMLDsig\Signature $signature
     */
    private $signature = null;

    /**
     * Gets as clave
     *
     * Clave numérica del comprobante
     *
     * @return string
     */
    public function getClave()
    {
        return $this->clave;
    }

    /**
     * Sets a new clave
     *
     * Clave numérica del comprobante
     *
     * @param string $clave
     * @return self
     */
    public function setClave($clave)
    {
        $this->clave = $clave;
        return $this;
    }

    /**
     * Gets as numeroCedulaEmisor
     *
     * Número de cédula fisica/jurídica/NITE/DIMEX/Extranjero No Domiciliado/No Contribuyente del vendedor
     *
     * @return string
     */
    public function getNumeroCedulaEmisor()
    {
        return $this->numeroCedulaEmisor;
    }

    /**
     * Sets a new numeroCedulaEmisor
     *
     * Número de cédula fisica/jurídica/NITE/DIMEX/Extranjero No Domiciliado/No Contribuyente del vendedor
     *
     * @param string $numeroCedulaEmisor
     * @return self
     */
    public function setNumeroCedulaEmisor($numeroCedulaEmisor)
    {
        $this->numeroCedulaEmisor = $numeroCedulaEmisor;
        return $this;
    }

    /**
     * Gets as fechaEmisionDoc
     *
     * Fecha de emision de la confirmación
     *
     * @return \DateTime
     */
    public function getFechaEmisionDoc()
    {
        return $this->fechaEmisionDoc;
    }

    /**
     * Sets a new fechaEmisionDoc
     *
     * Fecha de emision de la confirmación
     *
     * @param \DateTime $fechaEmisionDoc
     * @return self
     */
    public function setFechaEmisionDoc(\DateTime $fechaEmisionDoc)
    {
        $this->fechaEmisionDoc = $fechaEmisionDoc;
        return $this;
    }

    /**
     * Gets as mensaje
     *
     * Codigo del mensaje de respuesta. 1 aceptado, 2 aceptado parcialmente, 3 rechazado
     *
     * @return int
     */
    public function getMensaje()
    {
        return $this->mensaje;
    }

    /**
     * Sets a new mensaje
     *
     * Codigo del mensaje de respuesta. 1 aceptado, 2 aceptado parcialmente, 3 rechazado
     *
     * @param int $mensaje
     * @return self
     */
    public function setMensaje($mensaje)
    {
        $this->mensaje = $mensaje;
        return $this;
    }

    /**
     * Gets as detalleMensaje
     *
     * Detalle del mensaje
     *
     * @return string
     */
    public function getDetalleMensaje()
    {
        return $this->detalleMensaje;
    }

    /**
     * Sets a new detalleMensaje
     *
     * Detalle del mensaje
     *
     * @param string $detalleMensaje
     * @return self
     */
    public function setDetalleMensaje($detalleMensaje)
    {
        $this->detalleMensaje = $detalleMensaje;
        return $this;
    }

    /**
     * Gets as montoTotalImpuesto
     *
     * Monto total del impuesto, que es obligatorio si el comprobante tenga impuesto.
     *
     * @return float
     */
    public function getMontoTotalImpuesto()
    {
        return $this->montoTotalImpuesto;
    }

    /**
     * Sets a new montoTotalImpuesto
     *
     * Monto total del impuesto, que es obligatorio si el comprobante tenga impuesto.
     *
     * @param float $montoTotalImpuesto
     * @return self
     */
    public function setMontoTotalImpuesto($montoTotalImpuesto)
    {
        $this->montoTotalImpuesto = $montoTotalImpuesto;
        return $this;
    }

    /**
     * Gets as codigoActividad
     *
     * Código Actividad Económica
     *
     * @return string
     */
    public function getCodigoActividad()
    {
        return $this->codigoActividad;
    }

    /**
     * Sets a new codigoActividad
     *
     * Código Actividad Económica
     *
     * @param string $codigoActividad
     * @return self
     */
    public function setCodigoActividad($codigoActividad)
    {
        $this->codigoActividad = $codigoActividad;
        return $this;
    }

    /**
     * Gets as condicionImpuesto
     *
     * Condición del IVA. 01 General Credito IVA, 02 General Crédito parcial del IVA, 03 Bienes de Capital, 04 Gasto corriente no genera crédito, 05 Proporcionalidad
     *
     * @return string
     */
    public function getCondicionImpuesto()
    {
        return $this->condicionImpuesto;
    }

    /**
     * Sets a new condicionImpuesto
     *
     * Condición del IVA. 01 General Credito IVA, 02 General Crédito parcial del IVA, 03 Bienes de Capital, 04 Gasto corriente no genera crédito, 05 Proporcionalidad
     *
     * @param string $condicionImpuesto
     * @return self
     */
    public function setCondicionImpuesto($condicionImpuesto)
    {
        $this->condicionImpuesto = $condicionImpuesto;
        return $this;
    }

    /**
     * Gets as montoTotalImpuestoAcreditar
     *
     * Monto del Impuesto acreditar
     *
     * @return float
     */
    public function getMontoTotalImpuestoAcreditar()
    {
        return $this->montoTotalImpuestoAcreditar;
    }

    /**
     * Sets a new montoTotalImpuestoAcreditar
     *
     * Monto del Impuesto acreditar
     *
     * @param float $montoTotalImpuestoAcreditar
     * @return self
     */
    public function setMontoTotalImpuestoAcreditar($montoTotalImpuestoAcreditar)
    {
        $this->montoTotalImpuestoAcreditar = $montoTotalImpuestoAcreditar;
        return $this;
    }

    /**
     * Gets as montoTotalDeGastoAplicable
     *
     * Monto total del gasto a aplicar
     *
     * @return float
     */
    public function getMontoTotalDeGastoAplicable()
    {
        return $this->montoTotalDeGastoAplicable;
    }

    /**
     * Sets a new montoTotalDeGastoAplicable
     *
     * Monto total del gasto a aplicar
     *
     * @param float $montoTotalDeGastoAplicable
     * @return self
     */
    public function setMontoTotalDeGastoAplicable($montoTotalDeGastoAplicable)
    {
        $this->montoTotalDeGastoAplicable = $montoTotalDeGastoAplicable;
        return $this;
    }

    /**
     * Gets as totalFactura
     *
     * Monto total de la factura
     *
     * @return float
     */
    public function getTotalFactura()
    {
        return $this->totalFactura;
    }

    /**
     * Sets a new totalFactura
     *
     * Monto total de la factura
     *
     * @param float $totalFactura
     * @return self
     */
    public function setTotalFactura($totalFactura)
    {
        $this->totalFactura = $totalFactura;
        return $this;
    }

    /**
     * Gets as numeroCedulaReceptor
     *
     * Número de cédula fisica/jurídica/NITE/DIMEX/Extranjero No Domiciliado/No Contribuyente del comprador
     *
     * @return string
     */
    public function getNumeroCedulaReceptor()
    {
        return $this->numeroCedulaReceptor;
    }

    /**
     * Sets a new numeroCedulaReceptor
     *
     * Número de cédula fisica/jurídica/NITE/DIMEX/Extranjero No Domiciliado/No Contribuyente del comprador
     *
     * @param string $numeroCedulaReceptor
     * @return self
     */
    public function setNumeroCedulaReceptor($numeroCedulaReceptor)
    {
        $this->numeroCedulaReceptor = $numeroCedulaReceptor;
        return $this;
    }

    /**
     * Gets as numeroConsecutivoReceptor
     *
     * Numeración consecutiva de los mensajes de confirmación
     *
     * @return string
     */
    public function getNumeroConsecutivoReceptor()
    {
        return $this->numeroConsecutivoReceptor;
    }

    /**
     * Sets a new numeroConsecutivoReceptor
     *
     * Numeración consecutiva de los mensajes de confirmación
     *
     * @param string $numeroConsecutivoReceptor
     * @return self
     */
    public function setNumeroConsecutivoReceptor($numeroConsecutivoReceptor)
    {
        $this->numeroConsecutivoReceptor = $numeroConsecutivoReceptor;
        return $this;
    }

    /**
     * Gets as signature
     *
     * @return \App\XSDClasses\XMLDsig\Signature
     */
    public function getSignature()
    {
        return $this->signature;
    }

    /**
     * Sets a new signature
     *
     * @param \App\XSDClasses\XMLDsig\Signature $signature
     * @return self
     */
    public function setSignature(\App\XSDClasses\XMLDsig\Signature $signature)
    {
        $this->signature = $signature;
        return $this;
    }
}

