<?php

namespace App\XSDClasses\TiqueteElectronico;

use App\XSDClasses\TiqueteElectronico\TiqueteElectronico\TiqueteElectronicoAType;

/**
 * Class representing TiqueteElectronico
 *
 * Elemento Raiz del Tiquete Electrónico
 */
class TiqueteElectronico extends TiqueteElectronicoAType
{
}

