<?php

namespace App\XSDClasses\NotaCreditoElectronica;

use App\Models\Business;
use App\Models\ConditionSale;
use App\Models\Transaction;
use App\XSDClasses\NotaCreditoElectronica\NotaCreditoElectronica\NotaCreditoElectronicaAType;
use App\XSDClasses\NotaCreditoElectronica\NotaCreditoElectronica\NotaCreditoElectronicaAType\DetalleServicioAType;
use App\XSDClasses\NotaCreditoElectronica\NotaCreditoElectronica\NotaCreditoElectronicaAType\ResumenFacturaAType;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

/**
 * Class representing NotaCreditoElectronica
 *
 * Elemento Raiz de la Nota de Crédito
 */
class NotaCreditoElectronica extends NotaCreditoElectronicaAType
{
  private Transaction $transaction; // ✅ Propiedad corregida

  private $hasRegaliaOrBonificacion;

  /**
   * Constructor para inicializar la Factura Electrónica con los datos de la transacción.
   */
  public function __construct(Transaction $transaction)
  {
    $this->transaction = $transaction;

    // ✅ Asignación de valores al objeto FacturaElectronica
    $this->setClave($transaction->key);

    $business = Session::get('user.business');
    if (!$business) {
      $business = Business::find(1);
    }
    $this->setProveedorSistemas($business->proveedorSistemas);
    $this->setCodigoActividadEmisor($transaction->locationEconomicActivity->code);

    if (!is_null($transaction->contactEconomicActivity)) {
      $this->setCodigoActividadReceptor($transaction->contactEconomicActivity->code);
    }

    $this->setNumeroConsecutivo($transaction->consecutivo);

    $fechaEmision = Carbon::parse($transaction->transaction_date, 'America/Costa_Rica');

    $this->setFechaEmision($fechaEmision);

    // ✅ Configuración del Emisor
    $emisor = new EmisorType($this->transaction);
    // ✅ Asignar Emisor
    $this->setEmisor($emisor);

    // ✅ Configuración del Receptor
    $receptor = new ReceptorType($this->transaction);

    // ✅ Asignar Receptor
    $this->setReceptor($receptor);

    // ✅ Asignar La condición de venta
    $this->setCondicionVenta($this->transaction->condition_sale);

    if ($this->transaction->condition_sale == ConditionSale::OTHER) {
      $this->setCondicionVentaOtros($this->transaction->condition_sale_other);
    }

    if ($this->transaction->condition_sale == ConditionSale::CREDIT || $this->transaction->condition_sale == ConditionSale::SELLCREDIT) {
      $this->setPlazoCredito($this->transaction->pay_term_number);
    }

    if (!empty($this->transaction->lines)) {
      $detalle = new DetalleServicioAType($this->transaction->lines);
      $this->setDetalleServicio($detalle->getLineaDetalle());
    }

    if (!empty($this->transaction->otherCharges)) {
      foreach ($this->transaction->otherCharges as $cargo) {
        $otrosCargos = new OtrosCargosType($cargo);
        $this->addToOtrosCargos($otrosCargos);
      }
    }

    $resumenFactura = new ResumenFacturaAType($this->transaction);
    $this->setResumenFactura($resumenFactura);
  }
}
