<?php

namespace App\Models\XSD\FacturaElectronica;

use App\Models\Transaction;

/**
 * Class representing ReceptorType
 *
 *
 * XSD Type: ReceptorType
 */
class ReceptorType
{
  private Transaction $transaction; // ✅ Propiedad corregida

  /**
   * Constructor para inicializar la Factura Electrónica con los datos de la transacción.
   */
  public function __construct(Transaction $transaction)
  {
    $this->transaction = $transaction;

    $this->setNombre($transaction->contact->name);

    $identification = new IdentificacionType();
    $identification->setTipo($transaction->contact->identificationType->code);
    $identification->setNumero($transaction->contact->identification);
    $this->setIdentificacion($identification);

    if (!empty($transaction->contact->commercial_name)) {
      $this->setNombreComercial($transaction->contact->commercial_name);
    }

    // ✅ Configuración de Ubicación
    $ubicacion = new UbicacionType();
    if (!is_null($transaction->contact->province)) {
      $ubicacion->setProvincia($transaction->contact->province->code);
    }
    if (!is_null($transaction->contact->canton)) {
      $ubicacion->setCanton($transaction->contact->canton->code);
    }
    if (!is_null($transaction->contact->distrit)) {
      $ubicacion->setDistrito($transaction->contact->distrit->code);
    }
    if (!empty($transaction->contact->other_signs) && (!is_null($transaction->contact->identificationType->code) && ($transaction->contact->identificationType->code != IdentificacionType::EXTRANJERO))) {
      $ubicacion->setOtrasSenas($transaction->contact->other_signs);
    }
    $this->setUbicacion($ubicacion);

    if (!empty($transaction->contact->other_signs) && (!is_null($transaction->contact->identificationType->code) && ($transaction->contact->identificationType->code == IdentificacionType::EXTRANJERO))) {
      $this->setOtrasSenasExtranjero($transaction->contact->other_signs);
    }

    // ✅ Configuración de Teléfono
    if (!is_null($transaction->contact->country) && !is_null($transaction->contact->phone)) {
      $telefono = new TelefonoType();
      $telefono->setCodigoPais($transaction->contact->country->phonecode);
      $telefono->setNumTelefono($transaction->contact->phone);
      $this->setTelefono($telefono);
    }

    // ✅ Configuración de Email
    if (!empty($transaction->contact->email)) {
      $this->setCorreoElectronico($transaction->contact->email);
    }
  }

  /**
   * Nombre o razon social
   *
   * @var string $nombre
   */
  private $nombre = null;

  /**
   * @var \App\Models\XSD\FacturaElectronica\IdentificacionType $identificacion
   */
  private $identificacion = null;

  /**
   * En caso de que se cuente con nombre comercial debe indicarse
   *
   * @var string $nombreComercial
   */
  private $nombreComercial = null;

  /**
   * @var \App\Models\XSD\FacturaElectronica\UbicacionType $ubicacion
   */
  private $ubicacion = null;

  /**
   * Campo para incluir la direccion del extranjero, en caso de requerirse.
   *
   * @var string $otrasSenasExtranjero
   */
  private $otrasSenasExtranjero = null;

  /**
   * @var \App\Models\XSD\FacturaElectronica\TelefonoType $telefono
   */
  private $telefono = null;

  /**
   * Este campo será de condición obligatoria, cuando el cliente lo requiera. Debe cumplir con la siguiente estructura:
   *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
   *
   * @var string $correoElectronico
   */
  private $correoElectronico = null;

  /**
   * Gets as nombre
   *
   * Nombre o razon social
   *
   * @return string
   */
  public function getNombre()
  {
    return $this->nombre;
  }

  /**
   * Sets a new nombre
   *
   * Nombre o razon social
   *
   * @param string $nombre
   * @return self
   */
  public function setNombre($nombre)
  {
    $this->nombre = $nombre;
    return $this;
  }

  /**
   * Gets as identificacion
   *
   * @return \App\Models\XSD\FacturaElectronica\IdentificacionType
   */
  public function getIdentificacion()
  {
    return $this->identificacion;
  }

  /**
   * Sets a new identificacion
   *
   * @param \App\Models\XSD\FacturaElectronica\IdentificacionType $identificacion
   * @return self
   */
  public function setIdentificacion(\App\Models\XSD\FacturaElectronica\IdentificacionType $identificacion)
  {
    $this->identificacion = $identificacion;
    return $this;
  }

  /**
   * Gets as nombreComercial
   *
   * En caso de que se cuente con nombre comercial debe indicarse
   *
   * @return string
   */
  public function getNombreComercial()
  {
    return $this->nombreComercial;
  }

  /**
   * Sets a new nombreComercial
   *
   * En caso de que se cuente con nombre comercial debe indicarse
   *
   * @param string $nombreComercial
   * @return self
   */
  public function setNombreComercial($nombreComercial)
  {
    $this->nombreComercial = $nombreComercial;
    return $this;
  }

  /**
   * Gets as ubicacion
   *
   * @return \App\Models\XSD\FacturaElectronica\UbicacionType
   */
  public function getUbicacion()
  {
    return $this->ubicacion;
  }

  /**
   * Sets a new ubicacion
   *
   * @param \App\Models\XSD\FacturaElectronica\UbicacionType $ubicacion
   * @return self
   */
  public function setUbicacion(?\App\Models\XSD\FacturaElectronica\UbicacionType $ubicacion = null)
  {
    $this->ubicacion = $ubicacion;
    return $this;
  }

  /**
   * Gets as otrasSenasExtranjero
   *
   * Campo para incluir la direccion del extranjero, en caso de requerirse.
   *
   * @return string
   */
  public function getOtrasSenasExtranjero()
  {
    return $this->otrasSenasExtranjero;
  }

  /**
   * Sets a new otrasSenasExtranjero
   *
   * Campo para incluir la direccion del extranjero, en caso de requerirse.
   *
   * @param string $otrasSenasExtranjero
   * @return self
   */
  public function setOtrasSenasExtranjero($otrasSenasExtranjero)
  {
    $this->otrasSenasExtranjero = $otrasSenasExtranjero;
    return $this;
  }

  /**
   * Gets as telefono
   *
   * @return \App\Models\XSD\FacturaElectronica\TelefonoType
   */
  public function getTelefono()
  {
    return $this->telefono;
  }

  /**
   * Sets a new telefono
   *
   * @param \App\Models\XSD\FacturaElectronica\TelefonoType $telefono
   * @return self
   */
  public function setTelefono(?\App\Models\XSD\FacturaElectronica\TelefonoType $telefono = null)
  {
    $this->telefono = $telefono;
    return $this;
  }

  /**
   * Gets as correoElectronico
   *
   * Este campo será de condición obligatoria, cuando el cliente lo requiera. Debe cumplir con la siguiente estructura:
   *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
   *
   * @return string
   */
  public function getCorreoElectronico()
  {
    return $this->correoElectronico;
  }

  /**
   * Sets a new correoElectronico
   *
   * Este campo será de condición obligatoria, cuando el cliente lo requiera. Debe cumplir con la siguiente estructura:
   *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
   *
   * @param string $correoElectronico
   * @return self
   */
  public function setCorreoElectronico($correoElectronico)
  {
    $this->correoElectronico = $correoElectronico;
    return $this;
  }
}
