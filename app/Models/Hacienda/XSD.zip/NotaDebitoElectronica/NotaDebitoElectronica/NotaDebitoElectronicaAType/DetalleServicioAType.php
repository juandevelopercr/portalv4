<?php

namespace App\XSDClasses\NotaDebitoElectronica\NotaDebitoElectronica\NotaDebitoElectronicaAType;

/**
 * Class representing DetalleServicioAType
 */
class DetalleServicioAType
{
    /**
     * Cada línea del detalle de la mercancia o servicio prestado.
     *
     * @var \App\XSDClasses\NotaDebitoElectronica\NotaDebitoElectronica\NotaDebitoElectronicaAType\DetalleServicioAType\LineaDetalleAType[] $lineaDetalle
     */
    private $lineaDetalle = [
        
    ];

    /**
     * Adds as lineaDetalle
     *
     * Cada línea del detalle de la mercancia o servicio prestado.
     *
     * @return self
     * @param \App\XSDClasses\NotaDebitoElectronica\NotaDebitoElectronica\NotaDebitoElectronicaAType\DetalleServicioAType\LineaDetalleAType $lineaDetalle
     */
    public function addToLineaDetalle(\App\XSDClasses\NotaDebitoElectronica\NotaDebitoElectronica\NotaDebitoElectronicaAType\DetalleServicioAType\LineaDetalleAType $lineaDetalle)
    {
        $this->lineaDetalle[] = $lineaDetalle;
        return $this;
    }

    /**
     * isset lineaDetalle
     *
     * Cada línea del detalle de la mercancia o servicio prestado.
     *
     * @param int|string $index
     * @return bool
     */
    public function issetLineaDetalle($index)
    {
        return isset($this->lineaDetalle[$index]);
    }

    /**
     * unset lineaDetalle
     *
     * Cada línea del detalle de la mercancia o servicio prestado.
     *
     * @param int|string $index
     * @return void
     */
    public function unsetLineaDetalle($index)
    {
        unset($this->lineaDetalle[$index]);
    }

    /**
     * Gets as lineaDetalle
     *
     * Cada línea del detalle de la mercancia o servicio prestado.
     *
     * @return \App\XSDClasses\NotaDebitoElectronica\NotaDebitoElectronica\NotaDebitoElectronicaAType\DetalleServicioAType\LineaDetalleAType[]
     */
    public function getLineaDetalle()
    {
        return $this->lineaDetalle;
    }

    /**
     * Sets a new lineaDetalle
     *
     * Cada línea del detalle de la mercancia o servicio prestado.
     *
     * @param \App\XSDClasses\NotaDebitoElectronica\NotaDebitoElectronica\NotaDebitoElectronicaAType\DetalleServicioAType\LineaDetalleAType[] $lineaDetalle
     * @return self
     */
    public function setLineaDetalle(array $lineaDetalle)
    {
        $this->lineaDetalle = $lineaDetalle;
        return $this;
    }
}

