<?php

namespace App\XSDClasses\NotaDebitoElectronica;

use App\XSDClasses\NotaDebitoElectronica\NotaDebitoElectronica\NotaDebitoElectronicaAType;

/**
 * Class representing NotaDebitoElectronica
 *
 * Elemento Raiz de la Nota de Débito
 */
class NotaDebitoElectronica extends NotaDebitoElectronicaAType
{
}

