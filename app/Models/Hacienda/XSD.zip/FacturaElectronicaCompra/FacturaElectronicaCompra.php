<?php

namespace App\XSDClasses\FacturaElectronicaCompra;

use App\XSDClasses\FacturaElectronicaCompra\FacturaElectronicaCompra\FacturaElectronicaCompraAType;

/**
 * Class representing FacturaElectronicaCompra
 *
 * Elemento Raiz de la Facturacion Electrónica de Compra
 */
class FacturaElectronicaCompra extends FacturaElectronicaCompraAType
{
}

