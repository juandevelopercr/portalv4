<?php

namespace App\XSDClasses\ReciboElectronicoPago;

/**
 * Class representing EmisorType
 *
 * 
 * XSD Type: EmisorType
 */
class EmisorType
{
    /**
     * Nombre o razon social
     *
     * @var string $nombre
     */
    private $nombre = null;

    /**
     * @var \App\XSDClasses\ReciboElectronicoPago\IdentificacionType $identificacion
     */
    private $identificacion = null;

    /**
     * Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @var string[] $correoElectronico
     */
    private $correoElectronico = [
        
    ];

    /**
     * Gets as nombre
     *
     * Nombre o razon social
     *
     * @return string
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Sets a new nombre
     *
     * Nombre o razon social
     *
     * @param string $nombre
     * @return self
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
        return $this;
    }

    /**
     * Gets as identificacion
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\IdentificacionType
     */
    public function getIdentificacion()
    {
        return $this->identificacion;
    }

    /**
     * Sets a new identificacion
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\IdentificacionType $identificacion
     * @return self
     */
    public function setIdentificacion(\App\XSDClasses\ReciboElectronicoPago\IdentificacionType $identificacion)
    {
        $this->identificacion = $identificacion;
        return $this;
    }

    /**
     * Adds as correoElectronico
     *
     * Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @return self
     * @param string $correoElectronico
     */
    public function addToCorreoElectronico($correoElectronico)
    {
        $this->correoElectronico[] = $correoElectronico;
        return $this;
    }

    /**
     * isset correoElectronico
     *
     * Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @param int|string $index
     * @return bool
     */
    public function issetCorreoElectronico($index)
    {
        return isset($this->correoElectronico[$index]);
    }

    /**
     * unset correoElectronico
     *
     * Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @param int|string $index
     * @return void
     */
    public function unsetCorreoElectronico($index)
    {
        unset($this->correoElectronico[$index]);
    }

    /**
     * Gets as correoElectronico
     *
     * Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @return string[]
     */
    public function getCorreoElectronico()
    {
        return $this->correoElectronico;
    }

    /**
     * Sets a new correoElectronico
     *
     * Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @param string $correoElectronico
     * @return self
     */
    public function setCorreoElectronico(array $correoElectronico)
    {
        $this->correoElectronico = $correoElectronico;
        return $this;
    }
}

