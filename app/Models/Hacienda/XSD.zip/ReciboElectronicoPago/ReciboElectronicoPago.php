<?php

namespace App\XSDClasses\ReciboElectronicoPago;

use App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType;

/**
 * Class representing ReciboElectronicoPago
 *
 * Elemento Raiz del Recibo Electrónico de Pago
 */
class ReciboElectronicoPago extends ReciboElectronicoPagoAType
{
}

