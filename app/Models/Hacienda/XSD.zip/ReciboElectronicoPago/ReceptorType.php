<?php

namespace App\XSDClasses\ReciboElectronicoPago;

/**
 * Class representing ReceptorType
 *
 * 
 * XSD Type: ReceptorType
 */
class ReceptorType
{
    /**
     * Nombre o razon social
     *
     * @var string $nombre
     */
    private $nombre = null;

    /**
     * @var \App\XSDClasses\ReciboElectronicoPago\IdentificacionType $identificacion
     */
    private $identificacion = null;

    /**
     * Este campo será de condición obligatoria, cuando el cliente lo requiera. Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @var string $correoElectronico
     */
    private $correoElectronico = null;

    /**
     * Gets as nombre
     *
     * Nombre o razon social
     *
     * @return string
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * Sets a new nombre
     *
     * Nombre o razon social
     *
     * @param string $nombre
     * @return self
     */
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
        return $this;
    }

    /**
     * Gets as identificacion
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\IdentificacionType
     */
    public function getIdentificacion()
    {
        return $this->identificacion;
    }

    /**
     * Sets a new identificacion
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\IdentificacionType $identificacion
     * @return self
     */
    public function setIdentificacion(\App\XSDClasses\ReciboElectronicoPago\IdentificacionType $identificacion)
    {
        $this->identificacion = $identificacion;
        return $this;
    }

    /**
     * Gets as correoElectronico
     *
     * Este campo será de condición obligatoria, cuando el cliente lo requiera. Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @return string
     */
    public function getCorreoElectronico()
    {
        return $this->correoElectronico;
    }

    /**
     * Sets a new correoElectronico
     *
     * Este campo será de condición obligatoria, cuando el cliente lo requiera. Debe cumplir con la siguiente estructura: 
     *  \s*\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*\s*
     *
     * @param string $correoElectronico
     * @return self
     */
    public function setCorreoElectronico($correoElectronico)
    {
        $this->correoElectronico = $correoElectronico;
        return $this;
    }
}

