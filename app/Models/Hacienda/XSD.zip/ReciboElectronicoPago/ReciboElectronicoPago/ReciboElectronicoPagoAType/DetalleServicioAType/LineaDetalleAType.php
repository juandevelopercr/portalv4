<?php

namespace App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\DetalleServicioAType;

/**
 * Class representing LineaDetalleAType
 */
class LineaDetalleAType
{
    /**
     * Número de línea del detalle
     *
     * @var int $numeroLinea
     */
    private $numeroLinea = null;

    /**
     * Detalle de la mercancia transferida o servicio prestado
     *
     * @var string $detalle
     */
    private $detalle = null;

    /**
     * Se obtiene de multiplicar el campo cantidad por el campo precio unitario
     *
     * @var float $montoTotal
     */
    private $montoTotal = null;

    /**
     * Se obtiene de la resta del campo monto total menos monto de descuento concedido. En caso del Recibo Electrónico de Pago este campo será
     * editable y corresponderá al monto del pago a registrar para el
     * cálculo del IVA respectivo.
     *
     * @var float $subTotal
     */
    private $subTotal = null;

    /**
     * Cuando el producto o servicio este gravado con algún impuesto se debe indicar cada uno de ellos.
     *
     * @var \App\XSDClasses\ReciboElectronicoPago\ImpuestoType[] $impuesto
     */
    private $impuesto = [
        
    ];

    /**
     * Este monto se obtiene al restar el campo “Monto del Impuesto” menos “Monto del Impuesto Exonerado” o el
     * campo “Impuestos Asumidos por el Emisor o cobrado a Nivel de Fábrica” cuando corresponda.
     *
     * @var float $impuestoNeto
     */
    private $impuestoNeto = null;

    /**
     * Se calcula de la siguiente manera:
     * se obtiene de la sumatoria de los campos “Subtotal”, “Impuesto Neto”.
     *
     * @var float $montoTotalLinea
     */
    private $montoTotalLinea = null;

    /**
     * Gets as numeroLinea
     *
     * Número de línea del detalle
     *
     * @return int
     */
    public function getNumeroLinea()
    {
        return $this->numeroLinea;
    }

    /**
     * Sets a new numeroLinea
     *
     * Número de línea del detalle
     *
     * @param int $numeroLinea
     * @return self
     */
    public function setNumeroLinea($numeroLinea)
    {
        $this->numeroLinea = $numeroLinea;
        return $this;
    }

    /**
     * Gets as detalle
     *
     * Detalle de la mercancia transferida o servicio prestado
     *
     * @return string
     */
    public function getDetalle()
    {
        return $this->detalle;
    }

    /**
     * Sets a new detalle
     *
     * Detalle de la mercancia transferida o servicio prestado
     *
     * @param string $detalle
     * @return self
     */
    public function setDetalle($detalle)
    {
        $this->detalle = $detalle;
        return $this;
    }

    /**
     * Gets as montoTotal
     *
     * Se obtiene de multiplicar el campo cantidad por el campo precio unitario
     *
     * @return float
     */
    public function getMontoTotal()
    {
        return $this->montoTotal;
    }

    /**
     * Sets a new montoTotal
     *
     * Se obtiene de multiplicar el campo cantidad por el campo precio unitario
     *
     * @param float $montoTotal
     * @return self
     */
    public function setMontoTotal($montoTotal)
    {
        $this->montoTotal = $montoTotal;
        return $this;
    }

    /**
     * Gets as subTotal
     *
     * Se obtiene de la resta del campo monto total menos monto de descuento concedido. En caso del Recibo Electrónico de Pago este campo será
     * editable y corresponderá al monto del pago a registrar para el
     * cálculo del IVA respectivo.
     *
     * @return float
     */
    public function getSubTotal()
    {
        return $this->subTotal;
    }

    /**
     * Sets a new subTotal
     *
     * Se obtiene de la resta del campo monto total menos monto de descuento concedido. En caso del Recibo Electrónico de Pago este campo será
     * editable y corresponderá al monto del pago a registrar para el
     * cálculo del IVA respectivo.
     *
     * @param float $subTotal
     * @return self
     */
    public function setSubTotal($subTotal)
    {
        $this->subTotal = $subTotal;
        return $this;
    }

    /**
     * Adds as impuesto
     *
     * Cuando el producto o servicio este gravado con algún impuesto se debe indicar cada uno de ellos.
     *
     * @return self
     * @param \App\XSDClasses\ReciboElectronicoPago\ImpuestoType $impuesto
     */
    public function addToImpuesto(\App\XSDClasses\ReciboElectronicoPago\ImpuestoType $impuesto)
    {
        $this->impuesto[] = $impuesto;
        return $this;
    }

    /**
     * isset impuesto
     *
     * Cuando el producto o servicio este gravado con algún impuesto se debe indicar cada uno de ellos.
     *
     * @param int|string $index
     * @return bool
     */
    public function issetImpuesto($index)
    {
        return isset($this->impuesto[$index]);
    }

    /**
     * unset impuesto
     *
     * Cuando el producto o servicio este gravado con algún impuesto se debe indicar cada uno de ellos.
     *
     * @param int|string $index
     * @return void
     */
    public function unsetImpuesto($index)
    {
        unset($this->impuesto[$index]);
    }

    /**
     * Gets as impuesto
     *
     * Cuando el producto o servicio este gravado con algún impuesto se debe indicar cada uno de ellos.
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\ImpuestoType[]
     */
    public function getImpuesto()
    {
        return $this->impuesto;
    }

    /**
     * Sets a new impuesto
     *
     * Cuando el producto o servicio este gravado con algún impuesto se debe indicar cada uno de ellos.
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\ImpuestoType[] $impuesto
     * @return self
     */
    public function setImpuesto(?array $impuesto = null)
    {
        $this->impuesto = $impuesto;
        return $this;
    }

    /**
     * Gets as impuestoNeto
     *
     * Este monto se obtiene al restar el campo “Monto del Impuesto” menos “Monto del Impuesto Exonerado” o el
     * campo “Impuestos Asumidos por el Emisor o cobrado a Nivel de Fábrica” cuando corresponda.
     *
     * @return float
     */
    public function getImpuestoNeto()
    {
        return $this->impuestoNeto;
    }

    /**
     * Sets a new impuestoNeto
     *
     * Este monto se obtiene al restar el campo “Monto del Impuesto” menos “Monto del Impuesto Exonerado” o el
     * campo “Impuestos Asumidos por el Emisor o cobrado a Nivel de Fábrica” cuando corresponda.
     *
     * @param float $impuestoNeto
     * @return self
     */
    public function setImpuestoNeto($impuestoNeto)
    {
        $this->impuestoNeto = $impuestoNeto;
        return $this;
    }

    /**
     * Gets as montoTotalLinea
     *
     * Se calcula de la siguiente manera:
     * se obtiene de la sumatoria de los campos “Subtotal”, “Impuesto Neto”.
     *
     * @return float
     */
    public function getMontoTotalLinea()
    {
        return $this->montoTotalLinea;
    }

    /**
     * Sets a new montoTotalLinea
     *
     * Se calcula de la siguiente manera:
     * se obtiene de la sumatoria de los campos “Subtotal”, “Impuesto Neto”.
     *
     * @param float $montoTotalLinea
     * @return self
     */
    public function setMontoTotalLinea($montoTotalLinea)
    {
        $this->montoTotalLinea = $montoTotalLinea;
        return $this;
    }
}

