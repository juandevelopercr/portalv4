<?php

namespace App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType;

/**
 * Class representing ResumenFacturaAType
 */
class ResumenFacturaAType
{
    /**
     * @var \App\XSDClasses\ReciboElectronicoPago\CodigoMonedaType $codigoTipoMoneda
     */
    private $codigoTipoMoneda = null;

    /**
     * En caso del “Recibo Electronico de Pago” se obtiene de la suma de los montos totales de las líneas de detalle
     *
     * @var float $totalVenta
     */
    private $totalVenta = null;

    /**
     * Se obtiene de la resta de los campos total venta menos total descuento
     *
     * @var float $totalVentaNeta
     */
    private $totalVentaNeta = null;

    /**
     * Tipo complejo que contiene los montos desglosados por impuesto cobrado en el comprobante electrónico.
     *
     * @var \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\TotalDesgloseImpuestoAType[] $totalDesgloseImpuesto
     */
    private $totalDesgloseImpuesto = [
        
    ];

    /**
     * Se obtiene de la suma de todos campos monto del impuesto
     *
     * @var float $totalImpuesto
     */
    private $totalImpuesto = null;

    /**
     * @var \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\MedioPagoAType[] $medioPago
     */
    private $medioPago = [
        
    ];

    /**
     * Se obtiene de la suma de los campos “total venta neta”, “monto total del impuesto” y “total otros cargos” menos “total IVA devuelto”, en caso de contar con dichos campos.
     *
     * @var float $totalComprobante
     */
    private $totalComprobante = null;

    /**
     * Gets as codigoTipoMoneda
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\CodigoMonedaType
     */
    public function getCodigoTipoMoneda()
    {
        return $this->codigoTipoMoneda;
    }

    /**
     * Sets a new codigoTipoMoneda
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\CodigoMonedaType $codigoTipoMoneda
     * @return self
     */
    public function setCodigoTipoMoneda(\App\XSDClasses\ReciboElectronicoPago\CodigoMonedaType $codigoTipoMoneda)
    {
        $this->codigoTipoMoneda = $codigoTipoMoneda;
        return $this;
    }

    /**
     * Gets as totalVenta
     *
     * En caso del “Recibo Electronico de Pago” se obtiene de la suma de los montos totales de las líneas de detalle
     *
     * @return float
     */
    public function getTotalVenta()
    {
        return $this->totalVenta;
    }

    /**
     * Sets a new totalVenta
     *
     * En caso del “Recibo Electronico de Pago” se obtiene de la suma de los montos totales de las líneas de detalle
     *
     * @param float $totalVenta
     * @return self
     */
    public function setTotalVenta($totalVenta)
    {
        $this->totalVenta = $totalVenta;
        return $this;
    }

    /**
     * Gets as totalVentaNeta
     *
     * Se obtiene de la resta de los campos total venta menos total descuento
     *
     * @return float
     */
    public function getTotalVentaNeta()
    {
        return $this->totalVentaNeta;
    }

    /**
     * Sets a new totalVentaNeta
     *
     * Se obtiene de la resta de los campos total venta menos total descuento
     *
     * @param float $totalVentaNeta
     * @return self
     */
    public function setTotalVentaNeta($totalVentaNeta)
    {
        $this->totalVentaNeta = $totalVentaNeta;
        return $this;
    }

    /**
     * Adds as totalDesgloseImpuesto
     *
     * Tipo complejo que contiene los montos desglosados por impuesto cobrado en el comprobante electrónico.
     *
     * @return self
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\TotalDesgloseImpuestoAType $totalDesgloseImpuesto
     */
    public function addToTotalDesgloseImpuesto(\App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\TotalDesgloseImpuestoAType $totalDesgloseImpuesto)
    {
        $this->totalDesgloseImpuesto[] = $totalDesgloseImpuesto;
        return $this;
    }

    /**
     * isset totalDesgloseImpuesto
     *
     * Tipo complejo que contiene los montos desglosados por impuesto cobrado en el comprobante electrónico.
     *
     * @param int|string $index
     * @return bool
     */
    public function issetTotalDesgloseImpuesto($index)
    {
        return isset($this->totalDesgloseImpuesto[$index]);
    }

    /**
     * unset totalDesgloseImpuesto
     *
     * Tipo complejo que contiene los montos desglosados por impuesto cobrado en el comprobante electrónico.
     *
     * @param int|string $index
     * @return void
     */
    public function unsetTotalDesgloseImpuesto($index)
    {
        unset($this->totalDesgloseImpuesto[$index]);
    }

    /**
     * Gets as totalDesgloseImpuesto
     *
     * Tipo complejo que contiene los montos desglosados por impuesto cobrado en el comprobante electrónico.
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\TotalDesgloseImpuestoAType[]
     */
    public function getTotalDesgloseImpuesto()
    {
        return $this->totalDesgloseImpuesto;
    }

    /**
     * Sets a new totalDesgloseImpuesto
     *
     * Tipo complejo que contiene los montos desglosados por impuesto cobrado en el comprobante electrónico.
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\TotalDesgloseImpuestoAType[] $totalDesgloseImpuesto
     * @return self
     */
    public function setTotalDesgloseImpuesto(?array $totalDesgloseImpuesto = null)
    {
        $this->totalDesgloseImpuesto = $totalDesgloseImpuesto;
        return $this;
    }

    /**
     * Gets as totalImpuesto
     *
     * Se obtiene de la suma de todos campos monto del impuesto
     *
     * @return float
     */
    public function getTotalImpuesto()
    {
        return $this->totalImpuesto;
    }

    /**
     * Sets a new totalImpuesto
     *
     * Se obtiene de la suma de todos campos monto del impuesto
     *
     * @param float $totalImpuesto
     * @return self
     */
    public function setTotalImpuesto($totalImpuesto)
    {
        $this->totalImpuesto = $totalImpuesto;
        return $this;
    }

    /**
     * Adds as medioPago
     *
     * @return self
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\MedioPagoAType $medioPago
     */
    public function addToMedioPago(\App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\MedioPagoAType $medioPago)
    {
        $this->medioPago[] = $medioPago;
        return $this;
    }

    /**
     * isset medioPago
     *
     * @param int|string $index
     * @return bool
     */
    public function issetMedioPago($index)
    {
        return isset($this->medioPago[$index]);
    }

    /**
     * unset medioPago
     *
     * @param int|string $index
     * @return void
     */
    public function unsetMedioPago($index)
    {
        unset($this->medioPago[$index]);
    }

    /**
     * Gets as medioPago
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\MedioPagoAType[]
     */
    public function getMedioPago()
    {
        return $this->medioPago;
    }

    /**
     * Sets a new medioPago
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType\MedioPagoAType[] $medioPago
     * @return self
     */
    public function setMedioPago(array $medioPago)
    {
        $this->medioPago = $medioPago;
        return $this;
    }

    /**
     * Gets as totalComprobante
     *
     * Se obtiene de la suma de los campos “total venta neta”, “monto total del impuesto” y “total otros cargos” menos “total IVA devuelto”, en caso de contar con dichos campos.
     *
     * @return float
     */
    public function getTotalComprobante()
    {
        return $this->totalComprobante;
    }

    /**
     * Sets a new totalComprobante
     *
     * Se obtiene de la suma de los campos “total venta neta”, “monto total del impuesto” y “total otros cargos” menos “total IVA devuelto”, en caso de contar con dichos campos.
     *
     * @param float $totalComprobante
     * @return self
     */
    public function setTotalComprobante($totalComprobante)
    {
        $this->totalComprobante = $totalComprobante;
        return $this;
    }
}

