<?php

namespace App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago;

/**
 * Class representing ReciboElectronicoPagoAType
 */
class ReciboElectronicoPagoAType
{
    /**
     * Corresponde a la clave del comprobante. Es un campo de 50 posiciones y se tiene que utilizar para la consulta del código QR. Ver nota 1 y 4.1
     *
     * @var string $clave
     */
    private $clave = null;

    /**
     * Se debe indicar el número de cedula de identificación del proveedor
     * de sistemas que esté utilizando para la emisión de comprobantes
     * electrónicos
     *
     * @var string $proveedorSistemas
     */
    private $proveedorSistemas = null;

    /**
     * Numeración consecutiva del comprobante
     *
     * @var string $numeroConsecutivo
     */
    private $numeroConsecutivo = null;

    /**
     * @var \DateTime $fechaEmision
     */
    private $fechaEmision = null;

    /**
     * Emisor del documento
     *
     * @var \App\XSDClasses\ReciboElectronicoPago\EmisorType $emisor
     */
    private $emisor = null;

    /**
     * Receptor del documento
     *
     * @var \App\XSDClasses\ReciboElectronicoPago\ReceptorType $receptor
     */
    private $receptor = null;

    /**
     * Condiciones de la venta: 01 Contado, 02 Crédito, 03 Consignación, 04 Apartado, 05 Arrendamiento con opción de compra, 06 Arrendamiento en función financiera, 07 Cobro a favor de un tercero, 08 servicxios prestados al estado a credito, 09 pago del servicio prestado al estado,10 venta a crédito hasta 90 dias,11 pago de venta a crédito en IVA hasta 90 dias, 99 Otros
     *
     * @var string $condicionVenta
     */
    private $condicionVenta = null;

    /**
     * Detalle del Servicio, Mercancía u otro
     *
     * @var \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\DetalleServicioAType\LineaDetalleAType[] $detalleServicio
     */
    private $detalleServicio = null;

    /**
     * @var \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType $resumenFactura
     */
    private $resumenFactura = null;

    /**
     * @var \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\InformacionReferenciaAType[] $informacionReferencia
     */
    private $informacionReferencia = [
        
    ];

    /**
     * @var \App\XSDClasses\XMLDsig\Signature $signature
     */
    private $signature = null;

    /**
     * Gets as clave
     *
     * Corresponde a la clave del comprobante. Es un campo de 50 posiciones y se tiene que utilizar para la consulta del código QR. Ver nota 1 y 4.1
     *
     * @return string
     */
    public function getClave()
    {
        return $this->clave;
    }

    /**
     * Sets a new clave
     *
     * Corresponde a la clave del comprobante. Es un campo de 50 posiciones y se tiene que utilizar para la consulta del código QR. Ver nota 1 y 4.1
     *
     * @param string $clave
     * @return self
     */
    public function setClave($clave)
    {
        $this->clave = $clave;
        return $this;
    }

    /**
     * Gets as proveedorSistemas
     *
     * Se debe indicar el número de cedula de identificación del proveedor
     * de sistemas que esté utilizando para la emisión de comprobantes
     * electrónicos
     *
     * @return string
     */
    public function getProveedorSistemas()
    {
        return $this->proveedorSistemas;
    }

    /**
     * Sets a new proveedorSistemas
     *
     * Se debe indicar el número de cedula de identificación del proveedor
     * de sistemas que esté utilizando para la emisión de comprobantes
     * electrónicos
     *
     * @param string $proveedorSistemas
     * @return self
     */
    public function setProveedorSistemas($proveedorSistemas)
    {
        $this->proveedorSistemas = $proveedorSistemas;
        return $this;
    }

    /**
     * Gets as numeroConsecutivo
     *
     * Numeración consecutiva del comprobante
     *
     * @return string
     */
    public function getNumeroConsecutivo()
    {
        return $this->numeroConsecutivo;
    }

    /**
     * Sets a new numeroConsecutivo
     *
     * Numeración consecutiva del comprobante
     *
     * @param string $numeroConsecutivo
     * @return self
     */
    public function setNumeroConsecutivo($numeroConsecutivo)
    {
        $this->numeroConsecutivo = $numeroConsecutivo;
        return $this;
    }

    /**
     * Gets as fechaEmision
     *
     * @return \DateTime
     */
    public function getFechaEmision()
    {
        return $this->fechaEmision;
    }

    /**
     * Sets a new fechaEmision
     *
     * @param \DateTime $fechaEmision
     * @return self
     */
    public function setFechaEmision(\DateTime $fechaEmision)
    {
        $this->fechaEmision = $fechaEmision;
        return $this;
    }

    /**
     * Gets as emisor
     *
     * Emisor del documento
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\EmisorType
     */
    public function getEmisor()
    {
        return $this->emisor;
    }

    /**
     * Sets a new emisor
     *
     * Emisor del documento
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\EmisorType $emisor
     * @return self
     */
    public function setEmisor(\App\XSDClasses\ReciboElectronicoPago\EmisorType $emisor)
    {
        $this->emisor = $emisor;
        return $this;
    }

    /**
     * Gets as receptor
     *
     * Receptor del documento
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\ReceptorType
     */
    public function getReceptor()
    {
        return $this->receptor;
    }

    /**
     * Sets a new receptor
     *
     * Receptor del documento
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\ReceptorType $receptor
     * @return self
     */
    public function setReceptor(\App\XSDClasses\ReciboElectronicoPago\ReceptorType $receptor)
    {
        $this->receptor = $receptor;
        return $this;
    }

    /**
     * Gets as condicionVenta
     *
     * Condiciones de la venta: 01 Contado, 02 Crédito, 03 Consignación, 04 Apartado, 05 Arrendamiento con opción de compra, 06 Arrendamiento en función financiera, 07 Cobro a favor de un tercero, 08 servicxios prestados al estado a credito, 09 pago del servicio prestado al estado,10 venta a crédito hasta 90 dias,11 pago de venta a crédito en IVA hasta 90 dias, 99 Otros
     *
     * @return string
     */
    public function getCondicionVenta()
    {
        return $this->condicionVenta;
    }

    /**
     * Sets a new condicionVenta
     *
     * Condiciones de la venta: 01 Contado, 02 Crédito, 03 Consignación, 04 Apartado, 05 Arrendamiento con opción de compra, 06 Arrendamiento en función financiera, 07 Cobro a favor de un tercero, 08 servicxios prestados al estado a credito, 09 pago del servicio prestado al estado,10 venta a crédito hasta 90 dias,11 pago de venta a crédito en IVA hasta 90 dias, 99 Otros
     *
     * @param string $condicionVenta
     * @return self
     */
    public function setCondicionVenta($condicionVenta)
    {
        $this->condicionVenta = $condicionVenta;
        return $this;
    }

    /**
     * Adds as lineaDetalle
     *
     * Detalle del Servicio, Mercancía u otro
     *
     * @return self
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\DetalleServicioAType\LineaDetalleAType $lineaDetalle
     */
    public function addToDetalleServicio(\App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\DetalleServicioAType\LineaDetalleAType $lineaDetalle)
    {
        $this->detalleServicio[] = $lineaDetalle;
        return $this;
    }

    /**
     * isset detalleServicio
     *
     * Detalle del Servicio, Mercancía u otro
     *
     * @param int|string $index
     * @return bool
     */
    public function issetDetalleServicio($index)
    {
        return isset($this->detalleServicio[$index]);
    }

    /**
     * unset detalleServicio
     *
     * Detalle del Servicio, Mercancía u otro
     *
     * @param int|string $index
     * @return void
     */
    public function unsetDetalleServicio($index)
    {
        unset($this->detalleServicio[$index]);
    }

    /**
     * Gets as detalleServicio
     *
     * Detalle del Servicio, Mercancía u otro
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\DetalleServicioAType\LineaDetalleAType[]
     */
    public function getDetalleServicio()
    {
        return $this->detalleServicio;
    }

    /**
     * Sets a new detalleServicio
     *
     * Detalle del Servicio, Mercancía u otro
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\DetalleServicioAType\LineaDetalleAType[] $detalleServicio
     * @return self
     */
    public function setDetalleServicio(array $detalleServicio)
    {
        $this->detalleServicio = $detalleServicio;
        return $this;
    }

    /**
     * Gets as resumenFactura
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType
     */
    public function getResumenFactura()
    {
        return $this->resumenFactura;
    }

    /**
     * Sets a new resumenFactura
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType $resumenFactura
     * @return self
     */
    public function setResumenFactura(\App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\ResumenFacturaAType $resumenFactura)
    {
        $this->resumenFactura = $resumenFactura;
        return $this;
    }

    /**
     * Adds as informacionReferencia
     *
     * @return self
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\InformacionReferenciaAType $informacionReferencia
     */
    public function addToInformacionReferencia(\App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\InformacionReferenciaAType $informacionReferencia)
    {
        $this->informacionReferencia[] = $informacionReferencia;
        return $this;
    }

    /**
     * isset informacionReferencia
     *
     * @param int|string $index
     * @return bool
     */
    public function issetInformacionReferencia($index)
    {
        return isset($this->informacionReferencia[$index]);
    }

    /**
     * unset informacionReferencia
     *
     * @param int|string $index
     * @return void
     */
    public function unsetInformacionReferencia($index)
    {
        unset($this->informacionReferencia[$index]);
    }

    /**
     * Gets as informacionReferencia
     *
     * @return \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\InformacionReferenciaAType[]
     */
    public function getInformacionReferencia()
    {
        return $this->informacionReferencia;
    }

    /**
     * Sets a new informacionReferencia
     *
     * @param \App\XSDClasses\ReciboElectronicoPago\ReciboElectronicoPago\ReciboElectronicoPagoAType\InformacionReferenciaAType[] $informacionReferencia
     * @return self
     */
    public function setInformacionReferencia(array $informacionReferencia)
    {
        $this->informacionReferencia = $informacionReferencia;
        return $this;
    }

    /**
     * Gets as signature
     *
     * @return \App\XSDClasses\XMLDsig\Signature
     */
    public function getSignature()
    {
        return $this->signature;
    }

    /**
     * Sets a new signature
     *
     * @param \App\XSDClasses\XMLDsig\Signature $signature
     * @return self
     */
    public function setSignature(\App\XSDClasses\XMLDsig\Signature $signature)
    {
        $this->signature = $signature;
        return $this;
    }
}

