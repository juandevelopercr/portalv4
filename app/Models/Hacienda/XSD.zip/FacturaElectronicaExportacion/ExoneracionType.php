<?php

namespace App\XSDClasses\FacturaElectronicaExportacion;

/**
 * Class representing ExoneracionType
 *
 * 
 * XSD Type: ExoneracionType
 */
class ExoneracionType
{
    /**
     * Tipo de documento de exoneración o autorización. 01 Compras Autorizadas, 02 Ventas exentas a diplomáticos, 03 Autorizado por Ley Especial, 04 Exenciones Dirección General de Hacienda, 05 Transitorio V, 06 Transitorio IX, 07 Transitorio XVII, 99 Otros
     *
     * @var string $tipoDocumento
     */
    private $tipoDocumento = null;

    /**
     * Número de documento de exoneración o autorización
     *
     * @var string $numeroDocumento
     */
    private $numeroDocumento = null;

    /**
     * Nombre de la institución o dependencia que emitió la exoneración
     *
     * @var string $nombreInstitucion
     */
    private $nombreInstitucion = null;

    /**
     * Fecha y hora de la emisión del documento de exoneración o autorización.
     *
     * @var \DateTime $fechaEmision
     */
    private $fechaEmision = null;

    /**
     * Tarifa exonerada
     *
     * @var float $porcentajeExoneracion
     */
    private $porcentajeExoneracion = null;

    /**
     * Monto del impuesto exonerado
     *
     * @var float $montoExoneracion
     */
    private $montoExoneracion = null;

    /**
     * Gets as tipoDocumento
     *
     * Tipo de documento de exoneración o autorización. 01 Compras Autorizadas, 02 Ventas exentas a diplomáticos, 03 Autorizado por Ley Especial, 04 Exenciones Dirección General de Hacienda, 05 Transitorio V, 06 Transitorio IX, 07 Transitorio XVII, 99 Otros
     *
     * @return string
     */
    public function getTipoDocumento()
    {
        return $this->tipoDocumento;
    }

    /**
     * Sets a new tipoDocumento
     *
     * Tipo de documento de exoneración o autorización. 01 Compras Autorizadas, 02 Ventas exentas a diplomáticos, 03 Autorizado por Ley Especial, 04 Exenciones Dirección General de Hacienda, 05 Transitorio V, 06 Transitorio IX, 07 Transitorio XVII, 99 Otros
     *
     * @param string $tipoDocumento
     * @return self
     */
    public function setTipoDocumento($tipoDocumento)
    {
        $this->tipoDocumento = $tipoDocumento;
        return $this;
    }

    /**
     * Gets as numeroDocumento
     *
     * Número de documento de exoneración o autorización
     *
     * @return string
     */
    public function getNumeroDocumento()
    {
        return $this->numeroDocumento;
    }

    /**
     * Sets a new numeroDocumento
     *
     * Número de documento de exoneración o autorización
     *
     * @param string $numeroDocumento
     * @return self
     */
    public function setNumeroDocumento($numeroDocumento)
    {
        $this->numeroDocumento = $numeroDocumento;
        return $this;
    }

    /**
     * Gets as nombreInstitucion
     *
     * Nombre de la institución o dependencia que emitió la exoneración
     *
     * @return string
     */
    public function getNombreInstitucion()
    {
        return $this->nombreInstitucion;
    }

    /**
     * Sets a new nombreInstitucion
     *
     * Nombre de la institución o dependencia que emitió la exoneración
     *
     * @param string $nombreInstitucion
     * @return self
     */
    public function setNombreInstitucion($nombreInstitucion)
    {
        $this->nombreInstitucion = $nombreInstitucion;
        return $this;
    }

    /**
     * Gets as fechaEmision
     *
     * Fecha y hora de la emisión del documento de exoneración o autorización.
     *
     * @return \DateTime
     */
    public function getFechaEmision()
    {
        return $this->fechaEmision;
    }

    /**
     * Sets a new fechaEmision
     *
     * Fecha y hora de la emisión del documento de exoneración o autorización.
     *
     * @param \DateTime $fechaEmision
     * @return self
     */
    public function setFechaEmision(\DateTime $fechaEmision)
    {
        $this->fechaEmision = $fechaEmision;
        return $this;
    }

    /**
     * Gets as porcentajeExoneracion
     *
     * Tarifa exonerada
     *
     * @return float
     */
    public function getPorcentajeExoneracion()
    {
        return $this->porcentajeExoneracion;
    }

    /**
     * Sets a new porcentajeExoneracion
     *
     * Tarifa exonerada
     *
     * @param float $porcentajeExoneracion
     * @return self
     */
    public function setPorcentajeExoneracion($porcentajeExoneracion)
    {
        $this->porcentajeExoneracion = $porcentajeExoneracion;
        return $this;
    }

    /**
     * Gets as montoExoneracion
     *
     * Monto del impuesto exonerado
     *
     * @return float
     */
    public function getMontoExoneracion()
    {
        return $this->montoExoneracion;
    }

    /**
     * Sets a new montoExoneracion
     *
     * Monto del impuesto exonerado
     *
     * @param float $montoExoneracion
     * @return self
     */
    public function setMontoExoneracion($montoExoneracion)
    {
        $this->montoExoneracion = $montoExoneracion;
        return $this;
    }
}

