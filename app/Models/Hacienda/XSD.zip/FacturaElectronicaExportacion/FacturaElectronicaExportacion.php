<?php

namespace App\XSDClasses\FacturaElectronicaExportacion;

use App\XSDClasses\FacturaElectronicaExportacion\FacturaElectronicaExportacion\FacturaElectronicaExportacionAType;

/**
 * Class representing FacturaElectronicaExportacion
 *
 * Elemento Raiz de la Facturacion Electrónica de exportacion
 */
class FacturaElectronicaExportacion extends FacturaElectronicaExportacionAType
{
}

